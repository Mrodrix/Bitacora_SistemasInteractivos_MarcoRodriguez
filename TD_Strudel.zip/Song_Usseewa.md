const { visualid } = createParams('visualid')

setcpm(2.4)

const melody = note ("\[ B4@1.4 B5@1.4 B4@1.4 B5@1.4 B4@1.4 B5@1.4 B4@1.4 - B4 B5 A5 B5 C#6 D6 B5 A5 F#5@2 A#5@2 B5 -@3 B4@1.4 B5@1.4 B4@1.4 B5@1.4 B4@1.4 B5@1.4 B4@1.4 - E5 D5 E5 E#5 E5 D5 B4 D5 B4 - B5 A5 B5@2 -@3 E#5@2 E5 D5 B4 D5 B4 - B4 B4 C#5 D5 F#5 B5@2 D6 C#6@2 B5@2 B5 A5@3.5 E#5 E5 D5@2 B4@1.4 B5@1.4 B4@1.4 B5@1.4 B4@1.4 B5@1.4 B4@1.4 -@ B5 A5 B5 C#6 D6 C#6 B5 A5 B5 -@2 A5 B5 -@ A5@2 A5@2 A5 B5@2]").sound("piano").visualid("main")



const guitar = note("B3 F#4 B3 F#4 B3 F#4 B3 - G3 D4 G3 D4 F#3 C#4 F#3 C#4 E3 B3 E3 B3 F#3 C#4 F#3 C#4 B2").sound("gm\_electric\_guitar\_clean").gain(0.5).visualid("guitar")



const bass = note("\[B1 G1 F#1 E1 B1 G1 F#1 E1]\*2").sound("gm\_contrabass").visualid("bass")



$melody: stack (melody, melody.osc())

$guitar: stack(guitar, guitar.osc())

$bass: stack(bass, bass.osc())



